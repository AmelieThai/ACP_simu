# Tâche 19 : Prendre du recul

## Format du fichier de sauvegarde
Le format CSV (Comma Separated Values), ou ici avec séparateur `:`, fait penser à une **base de données relationnelle** simplifiée ou à une feuille de **tableur**. C'est un format structuré qui permet l'échange de données simple mais qui manque de métadonnées (types, relations explicites) sans convention externe.

## Gestion de plusieurs fermes
Si plusieurs fermes étaient gérées, pour distinguer les animaux appartenant à chacune :
1.  **Solution Base de Données (Clé étrangère)** : Ajouter un champ `id_ferme` ou `nom_ferme` dans chaque ligne du fichier `animaux.csv`. Chaque animal serait ainsi lié explicitement à une ferme.
2.  **Solution Fichiers Séparés** : Avoir un fichier d'animaux par ferme, par exemple `animaux_ferme1.csv`, `animaux_ferme2.csv`. Le fichier `fermes.csv` pourrait contenir le nom du fichier d'animaux associé.
3.  **Solution Hiérarchique (XML/JSON)** : Utiliser un format comme JSON ou XML où les animaux sont imbriqués dans la structure de données de la ferme correspondante.

## Diversification : Élevage d'escargots
L'ajout d'escargots aurait plusieurs conséquences :
1.  **Nouvelle Classe** : Création d'une classe `Escargot extends Animal`.
2.  **Attributs Spécifiques dont le Genre** : Les escargots sont hermaphrodites. L'attribut `boolean genre` de la classe `Animal` (Vrai=Femelle, Faux=Male) ne suffirait plus. Il faudrait soit :
    *   Changer le type de `genre` en `enum Sexe { MALE, FEMELLE, HERMAPHRODITE }`.
    *   Ou ignorer cet attribut pour les escargots.
3.  **Gestion des Stocks (Ressource)** :
    *   Les escargots ne mangent ni graines ni foin. Il faudrait ajouter `SALADE` (par exemple) à l'enum `Ressource`.
    *   Ils ne produisent ni lait ni œufs (sauf oeufs d'escargot, "caviar"). Il faut définir ce qu'ils produisent (chair, oeufs?).
4.  **Extensions de Ferme** :
    *   Mise à jour des méthodes `ajouterAnimal`, `acheterNourriture`, `vendreProduction` pour gérer ces nouveaux types.
    *   Mise à jour de `afficherApercu` pour compter les escargots.
5.  **Persistance** :
    *   Le format CSV devrait potentiellement être adapté si le genre n'est plus binaire ou si de nouveaux attributs spécifiques apparaissent.
