package acp.ferme;

import java.util.Random;

public class Utils {
    public static final double JOURS_PAR_AN = 365.25;
    public static final Random rng = new Random();

    // La méthode main est supprimée car cette classe sert maintenant d'utilitaire
}
