public class Types {
    public static void main(String[] args) {
        // Initialisation des variables
        byte b = 127;
        short s = 32767;
        int i = 2147483647;
        long l = 9223372036854775807L;
        float f = 1E-45f;
        double d = 1E-323;
        boolean bl = true;
        char c = 'A';
        String str = "Hello";

        // Affichage des valeurs initiales
        System.out.println("--- Valeurs initiales ---");
        System.out.println("byte: " + b);
        System.out.println("short: " + s);
        System.out.println("int: " + i);
        System.out.println("long: " + l);
        System.out.println("float: " + f);
        System.out.println("double: " + d);
        System.out.println("boolean: " + bl);
        System.out.println("char: " + c);
        System.out.println("String: " + str);

        // Modifications
        // Ajouter 1 à chaque valeur entière (y compris char)
        b = (byte) (b + 1); // Cast nécessaire car l'addition promeut en int
        s = (short) (s + 1); // Cast nécessaire
        i = i + 1;
        l = l + 1;
        c = (char) (c + 1);

        // Diviser les nombres flottants par 10
        f = f / 10;
        d = d / 10;

        // Inverser la valeur du booléen
        bl = !bl;

        // Ajouter " World!" à la chaîne de caractères
        str = str + " World!";

        // Affichage des valeurs modifiées
        System.out.println("\n--- Valeurs modifiées ---");
        System.out.println("byte (+1): " + b + " (Overflow!)");
        System.out.println("short (+1): " + s + " (Overflow!)");
        System.out.println("int (+1): " + i + " (Overflow!)");
        System.out.println("long (+1): " + l + " (Overflow!)");
        System.out.println("float (/10): " + f);
        System.out.println("double (/10): " + d);
        System.out.println("boolean (!): " + bl);
        System.out.println("char (+1): " + c);
        System.out.println("String (+): " + str);
    }
}
